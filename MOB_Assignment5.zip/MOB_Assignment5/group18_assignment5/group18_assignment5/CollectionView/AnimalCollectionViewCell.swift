//
//  AnimalCollectionViewCell.swift
//  group18_assignment5
//
//  Created by Group 18 on 10/13/19.
//  Copyright © 2019 Group 18. All rights reserved.
//

import UIKit

class AnimalCollectionViewCell: UICollectionViewCell {
    //MARK: Properties
    @IBOutlet weak var aniGalleryPhoto: UIImageView!
    @IBOutlet weak var aniGalleryCaption: UILabel!
    
    //var selectedAnimal = ""
}
